# Sakura Launcher (Android TV)

Màn hình chính tự viết cho tivi TCL Android TV:
- Nền động: hoa anh đào rơi + những lá bài lơ lửng (thiết kế gốc), có thể thay bằng ảnh nền riêng.
- Hai đồng hồ: Việt Nam (GMT+7) và Pennsylvania, Mỹ (giờ miền Đông, tự đổi EST/EDT).
- Lịch âm Việt Nam ngay dưới đồng hồ.
- Hàng ứng dụng dưới cùng: YouTube, Ứng dụng (xem tất cả app, ví dụ FPT Play), Cài đặt.

## 1. Tạo file APK bằng GitHub (không cần cài gì)

1. Tạo tài khoản GitHub (miễn phí) và một repository mới, ví dụ `SakuraLauncher`.
2. Tải toàn bộ nội dung thư mục này lên repository (giữ nguyên cấu trúc thư mục,
   nhớ cả thư mục ẩn `.github`).
3. Vào tab **Actions**, chọn workflow **Build APK**. Nếu chưa tự chạy, bấm **Run workflow**.
4. Chờ khoảng 3-5 phút. Khi xong, mở lần chạy đó, kéo xuống mục **Artifacts**,
   tải `SakuraLauncher-apk` (file zip, bên trong có `app-debug.apk`).

## 2. Cài lên tivi (qua Termux/ADB, đã kết nối tivi)

Chép `app-debug.apk` vào điện thoại (ví dụ thư mục Download), rồi:

```
adb install -r /sdcard/Download/app-debug.apk
```

Mở thử từ danh sách app của tivi: **Sakura Launcher**.

## 3. Đặt làm màn hình chính

Kiểm tra launcher đã được nhận:

```
adb shell cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME
```

Phải thấy `vn.tai.sakuralauncher/.MainActivity`. Rồi tắt launcher đang dùng
(AT4K), để nút Home mở Sakura Launcher:

```
adb shell pm disable-user --user 0 com.overdevs.at4k
```

Quay lại như cũ nếu có sự cố:

```
adb shell pm enable com.overdevs.at4k
adb shell pm enable com.google.android.tvlauncher
```

## 4. Đổi ảnh nền (dùng ảnh/hình của riêng bạn)

Chọn một ảnh ngang (tỉ lệ 16:9, độ phân giải 1920x1080 là đủ), đặt tên `background.jpg`
(hoặc `background.png`), rồi:

```
adb push background.jpg /sdcard/Android/data/vn.tai.sakuralauncher/files/background.jpg
```

Mở lại launcher (bấm Home) là nền đổi. Xóa file để quay về nền hoa anh đào mặc định:

```
adb shell rm /sdcard/Android/data/vn.tai.sakuralauncher/files/background.jpg
```

## 5. Tùy chỉnh trong mã

Mở `app/src/main/java/vn/tai/sakuralauncher/MainActivity.java`, phần `CẤU HÌNH`:
- `TZ_US`, `US_LABEL`: múi giờ và tên hiển thị của đồng hồ thứ hai.
- `US_12H`: `true` hiện kiểu 1:05 PM, `false` hiện 13:05.
- `YOUTUBE_PACKAGES`: tên gói YouTube.

Số lượng cánh hoa và lá bài chỉnh ở `SakuraView.java` (`PETAL_COUNT`, `CARD_COUNT`).
Nếu tivi vẫn thấy lag, giảm hai số này.
