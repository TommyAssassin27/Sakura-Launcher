package vn.tai.sakuralauncher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.io.File;
import java.util.Random;

/**
 * Nền động: hoa anh đào rơi + những lá bài lơ lửng (thiết kế gốc).
 * Có thể thay nền bằng ảnh riêng: đặt file background.jpg (hoặc .png) vào thư mục
 * /sdcard/Android/data/vn.tai.sakuralauncher/files/
 */
public class SakuraView extends View {

    private static final int PETAL_COUNT = 30;
    private static final int CARD_COUNT = 6;
    private static final long FRAME_MS = 33; // ~30 khung hình/giây cho nhẹ máy

    private final Random rnd = new Random();
    private final float density;

    // Cánh hoa
    private final float[] px = new float[PETAL_COUNT];
    private final float[] py = new float[PETAL_COUNT];
    private final float[] pSize = new float[PETAL_COUNT];
    private final float[] pSpeed = new float[PETAL_COUNT];
    private final float[] pPhase = new float[PETAL_COUNT];
    private final float[] pRot = new float[PETAL_COUNT];
    private final float[] pRotSpeed = new float[PETAL_COUNT];
    private final float[] pFlip = new float[PETAL_COUNT];
    private final int[] pColor = new int[PETAL_COUNT];

    // Lá bài
    private final float[] cx = new float[CARD_COUNT];
    private final float[] cy = new float[CARD_COUNT];
    private final float[] cW = new float[CARD_COUNT];
    private final float[] cVy = new float[CARD_COUNT];
    private final float[] cRot = new float[CARD_COUNT];
    private final float[] cRotSpeed = new float[CARD_COUNT];
    private final float[] cPhase = new float[CARD_COUNT];

    private final Path petalPath = new Path();
    private final Path starPath = new Path();
    private final Paint petalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cardFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cardStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint();
    private final Paint scrimPaint = new Paint();
    private final RectF cardRect = new RectF();
    private final Rect srcRect = new Rect();
    private final Rect dstRect = new Rect();

    private volatile Bitmap customBg;
    private volatile boolean srcDirty = true;
    private long customBgStamp = -1;
    private boolean active = false;
    private long lastNanos = 0;
    private float time = 0f;
    private int viewW = 0;
    private int viewH = 0;

    public SakuraView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;

        // Cánh hoa đơn vị (bán kính 1), đầu cánh có khía như hoa anh đào
        petalPath.moveTo(0f, -1f);
        petalPath.cubicTo(0.95f, -0.9f, 1.0f, 0.3f, 0.16f, 1.0f);
        petalPath.lineTo(0f, 0.78f);
        petalPath.lineTo(-0.16f, 1.0f);
        petalPath.cubicTo(-1.0f, 0.3f, -0.95f, -0.9f, 0f, -1f);
        petalPath.close();

        // Ngôi sao 5 cánh đơn vị
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            float r = (i % 2 == 0) ? 1f : 0.42f;
            float x = (float) (Math.cos(ang) * r);
            float y = (float) (Math.sin(ang) * r);
            if (i == 0) {
                starPath.moveTo(x, y);
            } else {
                starPath.lineTo(x, y);
            }
        }
        starPath.close();

        cardFill.setStyle(Paint.Style.FILL);
        cardFill.setColor(0x26FFFFFF);
        cardStroke.setStyle(Paint.Style.STROKE);
        cardStroke.setStrokeWidth(2f * density);
        cardStroke.setColor(0x99FFE3EE);
        starPaint.setStyle(Paint.Style.FILL);
        starPaint.setColor(0x88FFE9A8);

        int[] palette = {0xFFFFC9DC, 0xFFFFB3CF, 0xFFFFDCE8, 0xFFFFA6C4, 0xFFFFE6EF};
        for (int i = 0; i < PETAL_COUNT; i++) {
            pColor[i] = palette[rnd.nextInt(palette.length)];
        }
        setFocusable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        viewW = w;
        viewH = h;
        bgPaint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF241743, 0xFF6B2F6F, 0xFFE58DB0},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        scrimPaint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x22000000, 0x00000000, 0x99000000},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        for (int i = 0; i < PETAL_COUNT; i++) {
            resetPetal(i, true);
        }
        for (int i = 0; i < CARD_COUNT; i++) {
            resetCard(i, true);
        }
        srcDirty = true;
        reloadBackground();
    }

    private void resetPetal(int i, boolean anywhere) {
        px[i] = rnd.nextFloat() * Math.max(viewW, 1);
        py[i] = anywhere ? rnd.nextFloat() * Math.max(viewH, 1) : -20f * density;
        pSize[i] = (5f + rnd.nextFloat() * 8f) * density;
        pSpeed[i] = (28f + rnd.nextFloat() * 46f) * density;
        pPhase[i] = rnd.nextFloat() * 6.28f;
        pRot[i] = rnd.nextFloat() * 360f;
        pRotSpeed[i] = (rnd.nextFloat() - 0.5f) * 90f;
        pFlip[i] = rnd.nextFloat() * 6.28f;
    }

    private void resetCard(int i, boolean anywhere) {
        cW[i] = (46f + rnd.nextFloat() * 40f) * density;
        cx[i] = rnd.nextFloat() * Math.max(viewW, 1);
        cy[i] = anywhere ? rnd.nextFloat() * Math.max(viewH, 1)
                : viewH + cW[i] * 1.8f;
        cVy[i] = -(10f + rnd.nextFloat() * 16f) * density; // bay lên chậm
        cRot[i] = (rnd.nextFloat() - 0.5f) * 50f;
        cRotSpeed[i] = (rnd.nextFloat() - 0.5f) * 12f;
        cPhase[i] = rnd.nextFloat() * 6.28f;
    }

    /** Bật/tắt hoạt ảnh (gọi từ onResume/onPause của Activity). */
    public void setActive(boolean on) {
        if (active == on) {
            return;
        }
        active = on;
        if (on) {
            lastNanos = 0;
            reloadBackground();
            invalidate();
        }
    }

    /** Nạp lại ảnh nền riêng nếu file được thay đổi. */
    public void reloadBackground() {
        if (viewW <= 0 || viewH <= 0) {
            return;
        }
        File dir = getContext().getExternalFilesDir(null);
        File f = null;
        if (dir != null) {
            File jpg = new File(dir, "background.jpg");
            File png = new File(dir, "background.png");
            if (jpg.isFile()) {
                f = jpg;
            } else if (png.isFile()) {
                f = png;
            }
        }
        final File file = f;
        long stamp = (file == null) ? 0 : file.lastModified() + file.length();
        if (stamp == customBgStamp) {
            return;
        }
        customBgStamp = stamp;
        if (file == null) {
            customBg = null;
            postInvalidate();
            return;
        }
        final int w = viewW;
        final int h = viewH;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(file.getAbsolutePath(), o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) {
                        sample *= 2;
                    }
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = sample;
                    o2.inPreferredConfig = Bitmap.Config.RGB_565;
                    Bitmap b = BitmapFactory.decodeFile(file.getAbsolutePath(), o2);
                    customBg = b;
                    srcDirty = true;
                    postInvalidate();
                } catch (Throwable ignored) {
                    customBg = null;
                }
            }
        }).start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        active = false;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final int w = getWidth();
        final int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }

        long now = System.nanoTime();
        float dt = (lastNanos == 0) ? 0f : (now - lastNanos) / 1_000_000_000f;
        if (dt > 0.1f) {
            dt = 0.1f;
        }
        lastNanos = now;
        time += dt;

        // Nền
        Bitmap bg = customBg;
        if (bg != null) {
            if (srcDirty) {
                float scale = Math.max(w / (float) bg.getWidth(), h / (float) bg.getHeight());
                int sw = Math.min(bg.getWidth(), Math.round(w / scale));
                int sh = Math.min(bg.getHeight(), Math.round(h / scale));
                int sx = (bg.getWidth() - sw) / 2;
                int sy = (bg.getHeight() - sh) / 2;
                srcRect.set(sx, sy, sx + sw, sy + sh);
                dstRect.set(0, 0, w, h);
                srcDirty = false;
            }
            canvas.drawBitmap(bg, srcRect, dstRect, null);
        } else {
            canvas.drawRect(0, 0, w, h, bgPaint);
        }
        canvas.drawRect(0, 0, w, h, scrimPaint);

        // Lá bài
        for (int i = 0; i < CARD_COUNT; i++) {
            cy[i] += cVy[i] * dt;
            cRot[i] += cRotSpeed[i] * dt;
            float sway = (float) Math.sin(time * 0.5f + cPhase[i]) * 14f * density;
            if (cy[i] < -cW[i] * 1.8f) {
                resetCard(i, false);
            }
            float cw = cW[i];
            float ch = cw * 1.6f;
            canvas.save();
            canvas.translate(cx[i] + sway, cy[i]);
            canvas.rotate(cRot[i]);
            cardRect.set(-cw / 2, -ch / 2, cw / 2, ch / 2);
            canvas.drawRoundRect(cardRect, cw * 0.1f, cw * 0.1f, cardFill);
            canvas.drawRoundRect(cardRect, cw * 0.1f, cw * 0.1f, cardStroke);
            cardRect.inset(cw * 0.1f, cw * 0.1f);
            canvas.drawRoundRect(cardRect, cw * 0.06f, cw * 0.06f, cardStroke);
            canvas.drawCircle(0, 0, cw * 0.30f, cardStroke);
            canvas.save();
            canvas.scale(cw * 0.26f, cw * 0.26f);
            canvas.drawPath(starPath, starPaint);
            canvas.restore();
            canvas.restore();
        }

        // Cánh hoa anh đào
        for (int i = 0; i < PETAL_COUNT; i++) {
            py[i] += pSpeed[i] * dt;
            px[i] += ((float) Math.sin(time * 0.9f + pPhase[i]) * 22f + 14f) * density * dt;
            pRot[i] += pRotSpeed[i] * dt;
            pFlip[i] += 2.2f * dt;
            if (py[i] > h + 20f * density || px[i] > w + 30f * density) {
                resetPetal(i, false);
            }
            float s = pSize[i];
            float flip = 0.55f + 0.45f * (float) Math.cos(pFlip[i]);
            petalPaint.setColor(pColor[i]);
            petalPaint.setAlpha(215);
            canvas.save();
            canvas.translate(px[i], py[i]);
            canvas.rotate(pRot[i]);
            canvas.scale(s * flip, s);
            canvas.drawPath(petalPath, petalPaint);
            canvas.restore();
        }

        if (active) {
            postInvalidateDelayed(FRAME_MS);
        }
    }
}
