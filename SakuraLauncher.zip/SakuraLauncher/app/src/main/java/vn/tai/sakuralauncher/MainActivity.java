package vn.tai.sakuralauncher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class MainActivity extends Activity {

    // ====== CẤU HÌNH (sửa ở đây nếu muốn) ======
    private static final String TZ_VN = "Asia/Ho_Chi_Minh";
    private static final String TZ_US = "America/New_York"; // Pennsylvania dùng giờ miền Đông
    private static final String US_LABEL = "PENNSYLVANIA, MỸ";
    private static final boolean US_12H = true; // true: 1:05 PM, false: 13:05
    private static final String[] YOUTUBE_PACKAGES = {
            "com.google.android.youtube.tv",
            "com.google.android.youtube"
    };
    // ===========================================

    private static final String[] WEEKDAYS = {
            "Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TimeZone tzVn = TimeZone.getTimeZone(TZ_VN);
    private final TimeZone tzUs = TimeZone.getTimeZone(TZ_US);

    private SakuraView sakura;
    private TextView vnTime;
    private TextView vnDate;
    private TextView usLabel;
    private TextView usTime;
    private TextView usDate;
    private TextView lunarText;
    private View youtubeTile;
    private int lastLunarKey = -1;
    private float density;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateClocks();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 1000 - (now % 1000) + 20);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        buildUi();
    }

    private int dp(int v) {
        return Math.round(v * density);
    }

    private TextView text(float sp, int color, int style) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif-light", style));
        t.setShadowLayer(dp(4), 0, dp(1), 0xAA000000);
        t.setIncludeFontPadding(false);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        sakura = new SakuraView(this);
        root.addView(sakura, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        content.setPadding(dp(56), dp(36), dp(56), dp(36));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- Hai đồng hồ: Việt Nam | Pennsylvania ----
        LinearLayout clocks = new LinearLayout(this);
        clocks.setOrientation(LinearLayout.HORIZONTAL);
        clocks.setGravity(Gravity.TOP);
        content.addView(clocks, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout vnBlock = new LinearLayout(this);
        vnBlock.setOrientation(LinearLayout.VERTICAL);
        TextView vnLabel = text(14, 0xFFFFD6E6, Typeface.BOLD);
        vnLabel.setText("VIỆT NAM · GMT+7");
        vnTime = text(76, Color.WHITE, Typeface.NORMAL);
        vnDate = text(18, 0xFFFFFFFF, Typeface.NORMAL);
        vnBlock.addView(vnLabel);
        vnBlock.addView(vnTime);
        vnBlock.addView(vnDate);
        clocks.addView(vnBlock, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout usBlock = new LinearLayout(this);
        usBlock.setOrientation(LinearLayout.VERTICAL);
        usBlock.setGravity(Gravity.END);
        usLabel = text(14, 0xFFFFD6E6, Typeface.BOLD);
        usTime = text(76, Color.WHITE, Typeface.NORMAL);
        usDate = text(18, 0xFFFFFFFF, Typeface.NORMAL);
        usLabel.setGravity(Gravity.END);
        usTime.setGravity(Gravity.END);
        usDate.setGravity(Gravity.END);
        usBlock.addView(usLabel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        usBlock.addView(usTime, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        usBlock.addView(usDate, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        clocks.addView(usBlock, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // ---- Lịch âm ngay bên dưới đồng hồ ----
        lunarText = text(26, 0xFFFFF0F6, Typeface.BOLD);
        LinearLayout.LayoutParams lunarLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lunarLp.topMargin = dp(18);
        content.addView(lunarText, lunarLp);

        // ---- Khoảng trống giữa ----
        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- Hàng ứng dụng ở dưới ----
        LinearLayout tiles = new LinearLayout(this);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        tiles.setGravity(Gravity.CENTER_VERTICAL);
        tiles.setClipChildren(false);
        content.addView(tiles, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Drawable ytIcon = null;
        String ytPkg = findYoutube();
        if (ytPkg != null) {
            try {
                ytIcon = getPackageManager().getApplicationIcon(ytPkg);
            } catch (PackageManager.NameNotFoundException ignored) {
                ytIcon = null;
            }
        }
        if (ytIcon == null) {
            ytIcon = IconFactory.placeholder(this, "▶");
        }

        youtubeTile = makeTile(ytIcon, "YouTube", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openYoutube();
            }
        });
        addTile(tiles, youtubeTile);

        addTile(tiles, makeTile(IconFactory.apps(this), "Ứng dụng", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AllAppsActivity.class));
            }
        }));

        addTile(tiles, makeTile(IconFactory.settings(this), "Cài đặt", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        }));

        setContentView(root);
    }

    private void addTile(LinearLayout row, View tile) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(24);
        row.addView(tile, lp);
    }

    private View makeTile(Drawable icon, String label, View.OnClickListener click) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(dp(18), dp(14), dp(18), dp(12));
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setOnClickListener(click);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tile.addView(iv, new LinearLayout.LayoutParams(dp(104), dp(104)));

        TextView tv = text(16, Color.WHITE, Typeface.NORMAL);
        tv.setText(label);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(8);
        tile.addView(tv, tlp);

        tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    GradientDrawable g = new GradientDrawable();
                    g.setColor(0x40FFFFFF);
                    g.setCornerRadius(dp(18));
                    g.setStroke(dp(2), 0xDDFFFFFF);
                    v.setBackground(g);
                } else {
                    v.setBackground(null);
                }
                v.animate().scaleX(hasFocus ? 1.12f : 1f)
                        .scaleY(hasFocus ? 1.12f : 1f).setDuration(120).start();
            }
        });
        return tile;
    }

    // ---------- Mở ứng dụng ----------

    private String findYoutube() {
        PackageManager pm = getPackageManager();
        for (String pkg : YOUTUBE_PACKAGES) {
            if (pm.getLeanbackLaunchIntentForPackage(pkg) != null
                    || pm.getLaunchIntentForPackage(pkg) != null) {
                return pkg;
            }
        }
        return null;
    }

    private void openYoutube() {
        String pkg = findYoutube();
        if (pkg == null) {
            Toast.makeText(this, "Chưa cài YouTube trên tivi", Toast.LENGTH_LONG).show();
            return;
        }
        PackageManager pm = getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) {
            i = pm.getLaunchIntentForPackage(pkg);
        }
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(i);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Không mở được YouTube", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void openSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Không mở được Cài đặt", Toast.LENGTH_LONG).show();
        }
    }

    // ---------- Đồng hồ & lịch âm ----------

    private static String two(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static void setIfChanged(TextView tv, String s) {
        if (!s.contentEquals(tv.getText())) {
            tv.setText(s);
        }
    }

    private static String dateLine(Calendar c) {
        return WEEKDAYS[c.get(Calendar.DAY_OF_WEEK) - 1] + ", "
                + c.get(Calendar.DAY_OF_MONTH) + "/" + (c.get(Calendar.MONTH) + 1)
                + "/" + c.get(Calendar.YEAR);
    }

    private void updateClocks() {
        long now = System.currentTimeMillis();

        Calendar vn = Calendar.getInstance(tzVn);
        vn.setTimeInMillis(now);
        setIfChanged(vnTime, two(vn.get(Calendar.HOUR_OF_DAY)) + ":" + two(vn.get(Calendar.MINUTE)));
        setIfChanged(vnDate, dateLine(vn));

        Calendar us = Calendar.getInstance(tzUs);
        us.setTimeInMillis(now);
        String usTimeStr;
        if (US_12H) {
            int h = us.get(Calendar.HOUR);
            if (h == 0) {
                h = 12;
            }
            usTimeStr = h + ":" + two(us.get(Calendar.MINUTE))
                    + (us.get(Calendar.AM_PM) == Calendar.AM ? " AM" : " PM");
        } else {
            usTimeStr = two(us.get(Calendar.HOUR_OF_DAY)) + ":" + two(us.get(Calendar.MINUTE));
        }
        setIfChanged(usTime, usTimeStr);
        setIfChanged(usDate, dateLine(us));
        setIfChanged(usLabel, US_LABEL + " · "
                + (tzUs.inDaylightTime(new Date(now)) ? "EDT" : "EST"));

        int d = vn.get(Calendar.DAY_OF_MONTH);
        int m = vn.get(Calendar.MONTH) + 1;
        int y = vn.get(Calendar.YEAR);
        int key = y * 10000 + m * 100 + d;
        if (key != lastLunarKey) {
            lastLunarKey = key;
            LunarCalendar.Lunar l = LunarCalendar.fromSolar(d, m, y);
            setIfChanged(lunarText, "Âm lịch: " + l.day + "/" + l.month
                    + (l.leap ? " (nhuận)" : "") + " · năm " + LunarCalendar.canChiYear(l.year));
        }
    }

    // ---------- Vòng đời ----------

    @Override
    protected void onResume() {
        super.onResume();
        sakura.setActive(true);
        lastLunarKey = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
        youtubeTile.post(new Runnable() {
            @Override
            public void run() {
                youtubeTile.requestFocus();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        sakura.setActive(false);
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Bấm Home khi đang ở launcher: quay về ô đầu tiên
        if (youtubeTile != null) {
            youtubeTile.requestFocus();
        }
    }

    @Override
    public void onBackPressed() {
        // Launcher không thoát bằng nút Back
    }
}
