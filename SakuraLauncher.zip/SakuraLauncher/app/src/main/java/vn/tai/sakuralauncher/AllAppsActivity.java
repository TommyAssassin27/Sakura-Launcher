package vn.tai.sakuralauncher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Danh sách tất cả ứng dụng (để mở FPT Play, Cài đặt... khi cần). */
public class AllAppsActivity extends Activity {

    private static final class AppItem {
        String label;
        String pkg;
        String cls;
        android.graphics.drawable.Drawable icon;
    }

    private float density;
    private final List<AppItem> items = new ArrayList<AppItem>();

    private int dp(int v) {
        return Math.round(v * density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        loadApps();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF241743, 0xFF4A2457, 0xFF8A3F7A});
        root.setBackground(bg);
        root.setPadding(dp(56), dp(36), dp(56), dp(24));

        TextView title = new TextView(this);
        title.setText("Tất cả ứng dụng");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        GridView grid = new GridView(this);
        grid.setNumColumns(6);
        grid.setVerticalSpacing(dp(12));
        grid.setHorizontalSpacing(dp(12));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setClipToPadding(false);
        grid.setPadding(0, dp(20), 0, dp(20));
        GradientDrawable sel = new GradientDrawable();
        sel.setColor(0x44FFFFFF);
        sel.setCornerRadius(dp(16));
        sel.setStroke(dp(2), 0xDDFFFFFF);
        grid.setSelector(sel);
        grid.setAdapter(new AppAdapter(this));
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                launch(items.get(position));
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        grid.requestFocus();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<String>();
        seen.add(getPackageName());

        Intent leanback = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        Intent normal = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all = new ArrayList<ResolveInfo>();
        all.addAll(pm.queryIntentActivities(leanback, 0));
        all.addAll(pm.queryIntentActivities(normal, 0));

        for (ResolveInfo ri : all) {
            String pkg = ri.activityInfo.packageName;
            if (!seen.add(pkg)) {
                continue;
            }
            AppItem a = new AppItem();
            a.pkg = pkg;
            a.cls = ri.activityInfo.name;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.icon = ri.loadIcon(pm);
            items.add(a);
        }
        Collections.sort(items, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem x, AppItem y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
    }

    private void launch(AppItem a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setClassName(a.pkg, a.cls);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Không mở được " + a.label, Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "Không mở được " + a.label, Toast.LENGTH_LONG).show();
        }
    }

    private final class AppAdapter extends BaseAdapter {
        private final Context ctx;

        AppAdapter(Context ctx) {
            this.ctx = ctx;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout cell;
            ImageView iv;
            TextView tv;
            if (convertView == null) {
                cell = new LinearLayout(ctx);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(8), dp(12), dp(8), dp(10));
                iv = new ImageView(ctx);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                cell.addView(iv, new LinearLayout.LayoutParams(dp(88), dp(88)));
                tv = new TextView(ctx);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tv.setGravity(Gravity.CENTER);
                tv.setSingleLine(true);
                tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tlp.topMargin = dp(6);
                cell.addView(tv, tlp);
                cell.setTag(new View[]{iv, tv});
            } else {
                cell = (LinearLayout) convertView;
                View[] tag = (View[]) cell.getTag();
                iv = (ImageView) tag[0];
                tv = (TextView) tag[1];
            }
            AppItem a = items.get(position);
            iv.setImageDrawable(a.icon);
            tv.setText(a.label);
            return cell;
        }
    }
}
