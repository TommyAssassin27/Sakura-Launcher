package vn.tai.sakuralauncher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

/** Vẽ sẵn vài biểu tượng đơn giản để khỏi cần file ảnh. */
final class IconFactory {

    private static final int SIZE = 192;

    private IconFactory() {
    }

    private static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    private static Bitmap base(Canvas[] out) {
        Bitmap b = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        out[0] = new Canvas(b);
        Paint bg = fill(0xFF3A2A5C);
        out[0].drawRoundRect(new RectF(6, 6, SIZE - 6, SIZE - 6), 36, 36, bg);
        return b;
    }

    /** Lưới 3x3 ô vuông bo góc. */
    static Drawable apps(Context ctx) {
        Canvas[] c = new Canvas[1];
        Bitmap b = base(c);
        Paint p = fill(0xFFFFFFFF);
        float cell = 32f;
        float gap = 14f;
        float start = (SIZE - (3 * cell + 2 * gap)) / 2f;
        for (int r = 0; r < 3; r++) {
            for (int col = 0; col < 3; col++) {
                float x = start + col * (cell + gap);
                float y = start + r * (cell + gap);
                c[0].drawRoundRect(new RectF(x, y, x + cell, y + cell), 8, 8, p);
            }
        }
        return new BitmapDrawable(ctx.getResources(), b);
    }

    /** Bánh răng: vòng tròn + 8 răng. */
    static Drawable settings(Context ctx) {
        Canvas[] c = new Canvas[1];
        Bitmap b = base(c);
        Canvas canvas = c[0];
        Paint p = fill(0xFFFFFFFF);
        float cx = SIZE / 2f;
        float cy = SIZE / 2f;
        for (int i = 0; i < 8; i++) {
            canvas.save();
            canvas.rotate(i * 45f, cx, cy);
            canvas.drawRoundRect(new RectF(cx - 11, cy - 66, cx + 11, cy - 40), 5, 5, p);
            canvas.restore();
        }
        canvas.drawCircle(cx, cy, 48, p);
        Paint hole = fill(0xFF3A2A5C);
        canvas.drawCircle(cx, cy, 22, hole);
        return new BitmapDrawable(ctx.getResources(), b);
    }

    /** Biểu tượng mặc định khi chưa cài ứng dụng. */
    static Drawable placeholder(Context ctx, String letter) {
        Canvas[] c = new Canvas[1];
        Bitmap b = base(c);
        Paint t = fill(0xFFFFFFFF);
        t.setTextSize(96);
        t.setTextAlign(Paint.Align.CENTER);
        c[0].drawText(letter, SIZE / 2f, SIZE / 2f + 34, t);
        return new BitmapDrawable(ctx.getResources(), b);
    }
}
